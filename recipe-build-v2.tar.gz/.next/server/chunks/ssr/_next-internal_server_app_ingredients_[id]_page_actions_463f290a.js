module.exports=[37311,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_ingredients_%5Bid%5D_page_actions_463f290a.js.map