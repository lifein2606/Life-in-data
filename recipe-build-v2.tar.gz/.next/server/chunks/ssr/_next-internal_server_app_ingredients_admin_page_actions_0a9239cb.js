module.exports=[96817,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_ingredients_admin_page_actions_0a9239cb.js.map