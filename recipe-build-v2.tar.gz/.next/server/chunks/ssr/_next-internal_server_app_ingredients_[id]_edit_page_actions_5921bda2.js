module.exports=[7199,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_ingredients_%5Bid%5D_edit_page_actions_5921bda2.js.map