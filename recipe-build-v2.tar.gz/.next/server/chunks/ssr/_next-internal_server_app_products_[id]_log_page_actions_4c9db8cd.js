module.exports=[82641,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_products_%5Bid%5D_log_page_actions_4c9db8cd.js.map