globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/ce6c7fd29caea605.js",
    "static/chunks/25ef15e6c6fea384.js",
    "static/chunks/c37677feb9a6b30a.js",
    "static/chunks/ee06393c718d773d.js",
    "static/chunks/turbopack-5fbb9d74ad9b5702.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];