1:"$Sreact.fragment"
2:I[11282,["/_next/static/chunks/d5e289bff96cf0c1.js","/_next/static/chunks/0eed89cda4daeeed.js"],"ViewportBoundary"]
3:I[11282,["/_next/static/chunks/d5e289bff96cf0c1.js","/_next/static/chunks/0eed89cda4daeeed.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"imtlDdXVBIk3dzhpplDLb","rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1, maximum-scale=1, viewport-fit=cover, user-scalable=no"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Life in 鸡尾酒配方管理"}],["$","meta","1",{"name":"description","content":"鸡尾酒配方管理系统，专业的配方、成本、库存管理工具"}],["$","meta","2",{"name":"author","content":"Life in"}],["$","meta","3",{"name":"keywords","content":"鸡尾酒,配方管理,成本计算,库存管理,Life in"}]]}]}]}],null]}],"loading":null,"isPartial":false}
