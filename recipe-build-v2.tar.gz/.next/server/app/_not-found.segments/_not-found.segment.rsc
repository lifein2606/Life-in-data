1:"$Sreact.fragment"
2:I[99041,["/_next/static/chunks/f56fd7ab2135fad8.js","/_next/static/chunks/0eed89cda4daeeed.js","/_next/static/chunks/a9beac8b81943c97.js","/_next/static/chunks/69a43f169a4286cb.js"],"default"]
3:I[59683,["/_next/static/chunks/f56fd7ab2135fad8.js","/_next/static/chunks/0eed89cda4daeeed.js","/_next/static/chunks/a9beac8b81943c97.js","/_next/static/chunks/69a43f169a4286cb.js"],"default"]
0:{"buildId":"imtlDdXVBIk3dzhpplDLb","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
