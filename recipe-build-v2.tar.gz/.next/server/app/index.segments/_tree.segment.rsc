:HL["/_next/static/chunks/503aef36ce9e6b31.css","style"]
0:{"buildId":"imtlDdXVBIk3dzhpplDLb","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
